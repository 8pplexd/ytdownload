#!/bin/bash
python3 /home/runner/thing/ytdlr/ytdl.py download /home/runner/thing/vidios/ $1 /home/runner/thing/archive/