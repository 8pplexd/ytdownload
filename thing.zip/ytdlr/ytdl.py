from __future__ import unicode_literals

from pafys import pafy
import youtube_dl
import os
import shutil
import sys


'''

>python3 ytdl.py download [path to videos folder  eg. /Desktop/videos/] [video url] [archive folder]

   > downloads video from video url to videos folder

>python3 ytdl.py delete [path to videos folder  eg. /Desktop/videos]

   > deletes all videos in videos folder

'''


class ytdl:

  def __init__(self,path_to_videos_folder=None,video_url=None, path_to_archive_folder=None):
    self.path_to_videos_folder = path_to_videos_folder
    self.video_url = video_url
    self.path_to_archive_folder = path_to_archive_folder


  def downloader(self):

    def my_hook(d):
        if d['status'] == 'finished':
            print('Done downloading, now converting ...')

    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',       
        'verbose': True,
        'outtmpl': f'{self.path_to_videos_folder}newvid',
        'noplaylist' : True,        
        'progress_hooks': [my_hook],  
    }
    #vid = pafy.new(self.video_url)
    vidt = "newvid"#vid.title

    if f"{vidt}.mp4" not in os.listdir(self.path_to_videos_folder):
      with youtube_dl.YoutubeDL(ydl_opts) as ydl:
          ydl.download([self.video_url])

    os.rename(os.path.join(self.path_to_videos_folder,vidt),str(os.path.join(self.path_to_videos_folder,vidt + ".mp4")))
    return (os.path.join(self.path_to_videos_folder,vidt))

  def deleter(self):
    for filename in os.listdir(self.path_to_videos_folder):
      os.remove(os.path.join(self.path_to_videos_folder,filename))

  def archive(self):
    #vidsdir appends to signify all files within a directory
    vidsdir = (str(self.path_to_videos_folder)+"newvid.mp4")
    #use shutil to move files in vidsdir to archive defined by self
    shutil.move(vidsdir, self.path_to_archive_folder)
    #debug msg
    print("contents of \""+str(self.path_to_videos_folder)+"\" saved to \""+str(self.path_to_archive_folder)+"\".")

ytdl1 = ytdl(path_to_videos_folder=sys.argv[2],video_url=sys.argv[3], path_to_archive_folder=sys.argv[4])



if sys.argv[1] == "download":
  #ytdl1.deleter()
  ytdl1.archive()
  ytdl1.downloader()
elif sys.argv[1] == "delete":
  ytdl1.deleter()
